# Bronco Bot

A Discord bot with moderation, welcome messages, and button verification.

## Requirements
- Node.js 20 or newer
- A Discord application and bot

## Installation
1. Download or clone this repository.
2. Install dependencies with `npm install`.
3. Copy `.env.example` to `.env`.
4. Add your bot token and optional channel/role IDs to `.env`.
5. Start the bot with `npm start`.

## Commands
- `!help` - Show commands
- `!ping` - Check bot response
- `!verify` - Post a verification button
- `!clear 10` - Delete up to 100 recent messages
- `!kick @member [reason]` - Kick a member
- `!ban @member [reason]` - Ban a member
- `!timeout @member 10m [reason]` - Timeout a member
- `!untimeout @member` - Remove a timeout

## Discord setup
In the Discord Developer Portal, enable **Server Members Intent** and **Message Content Intent**.
Invite the bot with the permissions needed for the features you use, including Send Messages,
Embed Links, Read Message History, Manage Messages, Kick Members, Ban Members,
Moderate Members, and Manage Roles.

Place the bot's role above the verified role it must assign.

## Keep your token private
Keep your real token in `.env`. Never upload `.env` or publish your token. If exposed, reset it
in the Discord Developer Portal.
